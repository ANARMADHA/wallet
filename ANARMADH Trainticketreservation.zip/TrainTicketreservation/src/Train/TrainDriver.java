package Train;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

//import collection.map.Employee;

public class TrainDriver {

	public static void main(String[] args) {
		Map<Integer, Trainpojo> traindetails = new HashMap<>();
		traindetails.put(1001, new Trainpojo(1001,"ShatabdiExpress","Bangalore","Delhi",2500.0d));
		traindetails.put(1002, new Trainpojo(1002,"ShatabdiExpress","Bangalore","Delhi",2500.0d));
		traindetails.put(1003, new Trainpojo(1003,"ShatabdiExpress","Bangalore","Delhi",2500.0d));
		traindetails.put(1004, new Trainpojo(1004,"ShatabdiExpress","Bangalore","Delhi",2500.0d));
		traindetails.put(1005, new Trainpojo(1005,"ShatabdiExpress","Bangalore","Delhi",2500.0d));
		traindetails.put(1006, new Trainpojo(1006,"ShatabdiExpress","Bangalore","Delhi",2500.0d));
		
		Double price=0d;
		System.out.println("Enter the train No.:");

		Scanner scanner = new Scanner(System.in);
		Integer id= scanner.nextInt();
		
		Trainpojo currenttrain=traindetails.get(id);
		Double fare=currenttrain.getPrice();
		String source=currenttrain.getSource();
		String dest=currenttrain.getDestination();
//		String Pnr=String.join("_",source.charAt(0));
		String pnr=source.charAt(0)+"";
		String pnr1=dest.charAt(0)+"";
		pnr=pnr.concat(pnr1);
		LocalDate date=LocalDate.now();
		String Sdate=date.toString();
		Random rand = new Random();
		Integer rand_int1 = rand.nextInt(1000);
		String random=rand_int1.toString();
		pnr=pnr+"_"+Sdate+"_"+random;
		System.out.println(pnr);
		List<Passengerpojo> PasList = new ArrayList<>();
		List<Double> pricelist=new ArrayList<>();
		if(traindetails.containsKey(id)==true) {
			System.out.println("Enter the number of passengers:");
			Scanner scanner1 = new Scanner(System.in);
			Integer noofpassengers= scanner1.nextInt();
			for(int i=0;i<noofpassengers;i++) {
				System.out.println("Passenger Name: ");
		        String name = scanner.next();
		        System.out.println("Age.:");
				Scanner scanner2 = new Scanner(System.in);
				Integer age= scanner2.nextInt();
				
				System.out.println("Gender: ");
				Scanner scanner3 = new Scanner(System.in);
		        char gender = scanner3.next().charAt(0);
		        if(age<12) {
		        	price=fare*(50/100);
		        }
		        else if(age>60){price=fare*(60/100);}
		        else if(gender == 'f' || gender == 'F') {price=fare*(25/100);}
		        else price=fare;
		        PasList.add(new Passengerpojo(name,age,gender));
		        pricelist.add(price);
		 
			}
//			System.out.println(PasList);
//			System.out.println(pricelist);
			System.out.println("PNR: "+pnr);
			System.out.println("Train no: "+currenttrain.getTrain_no());
			System.out.println("From: "+currenttrain.getSource());
			System.out.println("To: "+currenttrain.getDestination());
			System.out.println("Travel Date: "+Sdate);
			System.out.println("Total Price: "+pricelist.stream()
		            .mapToLong(Double::longValue)
		            .sum());
			
		}
		
		else System.out.println("Invalid Train number,Please enter a valid number");
		

	}

}
